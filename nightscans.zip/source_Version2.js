// @aidoku/aidoku:0.6.0

const BASE_URL = "https://nightsup.net";

function fetchHtml(url) {
    const res = http.get(url, {
        headers: {
            "User-Agent": "Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac OS X) AppleWebKit/605.1.15"
        }
    });
    if (!res || res.status !== 200) return null;
    return res.body.string();
}

function parseMangas(html) {
    let mangas = [];
    const doc = DOM.parse(html);
    const entries = doc.select("article.post");
    for (const entry of entries) {
        const titleElement = entry.selectFirst("h2.entry-title a");
        const title = titleElement?.text() ?? "";
        const href = titleElement?.attr("href") ?? "";
        const imageElement = entry.selectFirst("img");
        const imageUrl =
            imageElement?.attr("data-src") ??
            imageElement?.attr("src") ??
            "";
        if (title && href && imageUrl) {
            mangas.push({
                id: extractMangaId(href),
                title,
                cover: imageUrl.startsWith("http")
                    ? imageUrl
                    : BASE_URL + imageUrl,
                url: href
            });
        }
    }
    return mangas;
}

function extractMangaId(url) {
    const parts = url.split("/").filter(x => x && x !== "series");
    return parts.pop() || "";
}

function extractChapterId(url) {
    return url.replace(`${BASE_URL}/`, "").replace(/\//g, "");
}

function extractChapterNumber(title) {
    const m = title.match(/chapter\s*(\d+(?:\.\d+)?)/i);
    return m ? parseFloat(m[1]) : 0;
}

function parseStatus(status) {
    if (!status) return 0;
    switch (status.trim().toLowerCase()) {
        case "ongoing":
        case "publishing":
            return 0;
        case "completed":
        case "finished":
            return 1;
        case "hiatus":
        case "on hold":
            return 2;
        default:
            return 3;
    }
}

function parseDate(dateString) {
    if (!dateString) return 0;
    // Format: "Jul 12, 2023"
    const d = Date.parse(dateString);
    return isNaN(d) ? 0 : Math.floor(d / 1000);
}

module.exports = {
    id: () => "nightsup",
    name: () => "NightSup",
    lang: () => "en",
    version: () => 1,

    popularManga: (page) => {
        const url = page > 1 ? `${BASE_URL}/page/${page}/` : BASE_URL;
        const html = fetchHtml(url);
        if (!html) return [];
        return parseMangas(html);
    },

    mangaDetails: (id) => {
        const url = `${BASE_URL}/series/${id}/`;
        const html = fetchHtml(url);
        if (!html) return null;
        const doc = DOM.parse(html);
        const title = doc.selectFirst("h1.entry-title")?.text() ?? "";
        const imageUrl =
            doc.selectFirst(".series-thumb img")?.attr("src") ?? "";
        const description =
            doc.selectFirst(".series-summary")?.text() ?? "";
        const author = doc.selectFirst(".author")?.text() ?? "";
        const status = parseStatus(
            doc.selectFirst(".status")?.text() ?? ""
        );
        let genres = [];
        for (const el of doc.select(".genres a")) {
            const genre = el.text();
            if (genre) genres.push(genre);
        }
        return {
            id,
            title,
            cover: imageUrl.startsWith("http")
                ? imageUrl
                : BASE_URL + imageUrl,
            url,
            description,
            author,
            status,
            genres
        };
    },

    chapters: (id) => {
        const url = `${BASE_URL}/series/${id}/`;
        const html = fetchHtml(url);
        if (!html) return [];
        const doc = DOM.parse(html);
        let chapters = [];
        const chapterElements = doc.select(".chapter-list .chapter-item");
        chapterElements.forEach((element) => {
            const linkElement = element.selectFirst("a");
            const href = linkElement?.attr("href") ?? "";
            const title = linkElement?.text() ?? "";
            if (href && title) {
                const chapterNumber = extractChapterNumber(title);
                const dateString =
                    element.selectFirst(".chapter-date")?.text() ?? "";
                const date = parseDate(dateString);
                chapters.push({
                    id: extractChapterId(href),
                    title,
                    chapter: chapterNumber,
                    url: href,
                    date: date,
                    scanlator: "Night Scans"
                });
            }
        });
        return chapters.reverse();
    },

    chapterPages: (id) => {
        const url = `${BASE_URL}/${id}/`;
        const html = fetchHtml(url);
        if (!html) return [];
        const doc = DOM.parse(html);
        let pages = [];
        const imageElements = doc.select(
            ".chapter-content img, .reading-content img"
        );
        imageElements.forEach((element, index) => {
            const imageUrl =
                element.attr("data-src") || element.attr("src") || "";
            if (imageUrl) {
                pages.push({
                    index: index,
                    url: imageUrl.startsWith("http")
                        ? imageUrl
                        : BASE_URL + imageUrl
                });
            }
        });
        return pages;
    },

    search: (query, page) => {
        const searchUrl = `${BASE_URL}/?s=${encodeURIComponent(query)}`;
        const html = fetchHtml(searchUrl);
        if (!html) return [];
        return parseMangas(html);
    }
};